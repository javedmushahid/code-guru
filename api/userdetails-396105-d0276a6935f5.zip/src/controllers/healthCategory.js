const express = require("express");
const { loggerUtil } = require("../utils/logger");
const {
    OK,
    WRONG_ENTITY,
    BAD_REQUEST,
    NOT_FOUND,
    UNAUTHORIZED,
    INTERNAL_SERVER_ERROR,
  } = require("../utils/statusCode");
  const HealthCategory = require("../models/HealthCategory");



  const addHealthCategory=async()=>{
    
  }
